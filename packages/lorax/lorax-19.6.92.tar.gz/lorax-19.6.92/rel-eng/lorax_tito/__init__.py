from .tagger import LoraxRHELTagger

all = [LoraxRHELTagger]
